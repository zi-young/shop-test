import React from 'react';

const fabric = () => {
    return (
        <div>
            <h2>패브릭</h2>
        </div>
    );
};

export default fabric;