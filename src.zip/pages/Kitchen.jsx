import React from 'react';

const Kitchen = () => {
    return (
        <div>
            <h2>주방용품</h2>
        </div>
    );
};

export default Kitchen;