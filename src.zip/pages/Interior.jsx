import React from 'react';

const interior = () => {
    return (
        <div>
            <h2>인테리어</h2>
        </div>
    );
};

export default interior;