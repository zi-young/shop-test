import React from 'react';

const Office = () => {
    return (
        <div>
            <h2>사무용품</h2>
        </div>
    );
};

export default Office;